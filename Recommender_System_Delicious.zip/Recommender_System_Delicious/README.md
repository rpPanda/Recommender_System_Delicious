# Recommender-System-Using-Delicous_DataSet
• Designed and implemented a Recommender System for the Delicious Dataset to produce bookmark and friend Recommendations.
• Around 67k Bookmarks and 55k tags.
• More time efficient than previous approaches and produced desired results with a marked increase in user satisfaction and precision metrics. 
